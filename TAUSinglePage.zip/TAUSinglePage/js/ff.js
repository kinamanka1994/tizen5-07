 
 
var jsonString = '                          \
{                                           \
  "orderID": 12345,                         \
  "shopperName": "Ваня Иванов",             \
  "shopperEmail": "ivanov@example.com",     \
  "contents": [                             \
    {                                       \
      "productID": 34,                      \
      "productName": "Супер товар",         \
      "url": "http://volshebnaya-eda.ru/wp-content/uploads/2013/06/ic-29-810x608.jpg "                       \
    },                                      \
    {                                       \
      "productID": 56,                      \
      "productName": "Чудо товар",          \
      "url": "http://volshebnaya-eda.ru/wp-content/uploads/2013/06/ic-29-810x608.jpg "                         \
    }                                       \
  ],                                        \
  "orderCompleted": true                    \
}                                           \
';
 function start(){
var cart = JSON.parse ( jsonString );
 
document.getElementById('res1').innerHTML = cart.shopperEmail ;
document.getElementById('res2').innerHTML =   cart.contents[1].productName ;
document.getElementById('res3').innerHTML = cart.contents[1].productID ;
document.getElementById('res4').innerHTML = cart.contents[1].url ;
 }
 
